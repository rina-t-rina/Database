-- MySQL dump 10.13  Distrib 8.0.44, for macos15 (arm64)
--
-- Host: 127.0.0.1    Database: corona_nrdb
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'd3b460b6-cf99-11f0-9885-6c05d313e649:1-6748';

--
-- Table structure for table `protein_structure`
--

DROP TABLE IF EXISTS `protein_structure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `protein_structure` (
  `protein_pk` int NOT NULL,
  `pdb_id` char(4) NOT NULL,
  `entity_id` varchar(16) DEFAULT NULL,
  `asym_ids` json DEFAULT NULL,
  `auth_asym_ids` json DEFAULT NULL,
  `mapping_source` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`protein_pk`,`pdb_id`),
  KEY `pdb_id` (`pdb_id`),
  CONSTRAINT `protein_structure_ibfk_1` FOREIGN KEY (`protein_pk`) REFERENCES `protein` (`protein_pk`) ON DELETE CASCADE,
  CONSTRAINT `protein_structure_ibfk_2` FOREIGN KEY (`pdb_id`) REFERENCES `pdb_entry` (`pdb_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `protein_structure`
--

LOCK TABLES `protein_structure` WRITE;
/*!40000 ALTER TABLE `protein_structure` DISABLE KEYS */;
INSERT INTO `protein_structure` VALUES (2,'7D6H','1','[\"A\"]','[\"A\"]','uniprot'),(2,'7EIZ','3','[\"C\"]','[\"C\"]','uniprot'),(2,'7OFU','1','[\"A\"]','[\"AAA\"]','uniprot'),(2,'7P51','1','[\"A\"]','[\"A\"]','uniprot'),(2,'7QL8','1','[\"A\"]','[\"AAA\"]','uniprot'),(2,'7TZJ','1','[\"A\", \"B\"]','[\"A\", \"B\"]','uniprot'),(3,'6LVN','1','[\"A\", \"B\", \"C\", \"D\"]','[\"A\", \"B\", \"C\", \"D\"]','uniprot'),(3,'6LXT','1','[\"A\", \"B\", \"C\", \"D\", \"E\", \"F\"]','[\"A\", \"B\", \"C\", \"D\", \"E\", \"F\"]','uniprot'),(3,'6LZG','2','[\"B\"]','[\"B\"]','uniprot'),(3,'6M0J','2','[\"B\"]','[\"E\"]','uniprot'),(3,'6M17','3','[\"C\", \"F\"]','[\"E\", \"F\"]','uniprot'),(3,'6M1V','1','[\"A\"]','[\"A\"]','uniprot'),(3,'6VSB','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6VW1','2','[\"C\", \"D\"]','[\"E\", \"F\"]','uniprot'),(3,'6VXX','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6VYB','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6W41','3','[\"C\"]','[\"C\"]','uniprot'),(3,'6WPS','1','[\"A\", \"D\", \"G\"]','[\"A\", \"B\", \"E\"]','uniprot'),(3,'6WPT','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6X29','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6X2A','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6X2B','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6X2C','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6X45','1','[\"A\", \"B\", \"D\"]','[\"D\", \"E\", \"F\"]','uniprot'),(3,'6X6P','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6X79','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XC2','1','[\"A\", \"D\"]','[\"A\", \"Z\"]','uniprot'),(3,'6XC3','5','[\"E\"]','[\"C\"]','uniprot'),(3,'6XC4','1','[\"A\", \"D\"]','[\"A\", \"Z\"]','uniprot'),(3,'6XC7','1','[\"A\"]','[\"A\"]','uniprot'),(3,'6XCM','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XCN','1','[\"A\", \"B\", \"C\"]','[\"A\", \"C\", \"E\"]','uniprot'),(3,'6XDG','1','[\"A\"]','[\"E\"]','uniprot'),(3,'6XE1','3','[\"C\"]','[\"E\"]','uniprot'),(3,'6XEY','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XF5','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XF6','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XKL','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XKP','1','[\"A\", \"B\"]','[\"A\", \"B\"]','uniprot'),(3,'6XKQ','1','[\"A\"]','[\"A\"]','uniprot'),(3,'6XLU','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XM0','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XM3','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XM4','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XM5','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XR8','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XRA','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6XS6','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6YLA','1','[\"A\", \"D\"]','[\"A\", \"E\"]','uniprot'),(3,'6YM0','1','[\"A\"]','[\"E\"]','uniprot'),(3,'6YOR','1','[\"A\", \"D\"]','[\"A\", \"E\"]','uniprot'),(3,'6YZ5','1','[\"A\"]','[\"E\"]','uniprot'),(3,'6YZ7','1','[\"A\", \"E\"]','[\"AAA\", \"EEE\"]','uniprot'),(3,'6Z2M','1','[\"A\", \"D\"]','[\"A\", \"E\"]','uniprot'),(3,'6Z43','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6Z97','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZB4','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZB5','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZBP','1','[\"A\"]','[\"EEE\"]','uniprot'),(3,'6ZCZ','1','[\"A\"]','[\"E\"]','uniprot'),(3,'6ZDG','1','[\"A\", \"D\", \"G\"]','[\"A\", \"D\", \"E\"]','uniprot'),(3,'6ZDH','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZER','1','[\"A\", \"D\", \"G\"]','[\"A\", \"D\", \"E\"]','uniprot'),(3,'6ZFO','1','[\"A\", \"D\"]','[\"A\", \"E\"]','uniprot'),(3,'6ZGE','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZGG','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZGI','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZH9','3','[\"C\"]','[\"EEE\"]','uniprot'),(3,'6ZHD','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZLR','1','[\"A\", \"D\", \"G\"]','[\"AAA\", \"DDD\", \"EEE\"]','uniprot'),(3,'6ZOW','1','[\"A\", \"B\", \"C\", \"D\"]','[\"A\", \"B\", \"C\", \"a\"]','uniprot'),(3,'6ZOX','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZOY','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZOZ','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZP0','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZP1','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZP2','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZP5','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZP7','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZWV','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'6ZXN','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A25','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A29','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A4N','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A5R','3','[\"C\", \"D\"]','[\"A\", \"B\"]','uniprot'),(3,'7A5S','3','[\"C\", \"E\"]','[\"A\", \"B\"]','uniprot'),(3,'7A91','2','[\"B\"]','[\"A\"]','uniprot'),(3,'7A92','2','[\"B\"]','[\"A\"]','uniprot'),(3,'7A93','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A94','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A95','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A96','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A97','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7A98','1','[\"A\", \"E\", \"F\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7AD1','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7AKD','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7B0B','3','[\"C\"]','[\"F\"]','uniprot'),(3,'7B14','1','[\"A\"]','[\"A\"]','uniprot'),(3,'7B17','1','[\"A\"]','[\"A\"]','uniprot'),(3,'7B18','1','[\"A\", \"B\", \"C\"]','[\"A\", \"B\", \"C\"]','uniprot'),(3,'7B3O','1','[\"A\"]','[\"E\"]','uniprot'),(3,'7B62','1','[\"A\"]','[\"A\"]','uniprot'),(3,'7BEH','1','[\"A\"]','[\"E\"]','uniprot'),(3,'7BEI','3','[\"C\"]','[\"E\"]','uniprot'),(3,'7BEJ','3','[\"C\"]','[\"E\"]','uniprot'),(3,'7BEK','3','[\"C\"]','[\"E\"]','uniprot'),(5,'7K3G','1','[\"A\", \"B\", \"C\", \"D\", \"E\"]','[\"A\", \"B\", \"C\", \"D\", \"E\"]','uniprot'),(5,'7M4R','2','[\"C\"]','[\"C\"]','uniprot'),(5,'7NTK','2','[\"C\", \"E\", \"G\", \"H\"]','[\"C\", \"E\", \"G\", \"H\"]','uniprot'),(5,'7QCR','2','[\"C\", \"D\"]','[\"C\", \"D\"]','uniprot'),(5,'7QCS','2','[\"C\", \"D\"]','[\"C\", \"D\"]','uniprot'),(5,'7QCT','2','[\"C\", \"D\"]','[\"C\", \"D\"]','uniprot'),(5,'7TUQ','2','[\"C\"]','[\"C\"]','uniprot'),(5,'7TV0','2','[\"E\", \"F\"]','[\"E\", \"G\"]','uniprot'),(5,'8SUZ','1','[\"A\", \"B\", \"C\", \"D\", \"E\"]','[\"A\", \"B\", \"C\", \"D\", \"E\"]','uniprot'),(5,'8U1T','1','[\"A\", \"B\"]','[\"A\", \"B\"]','uniprot'),(6,'7VGR','3','[\"E\", \"F\"]','[\"A\", \"B\"]','uniprot'),(6,'7VGS','1','[\"A\", \"D\"]','[\"A\", \"B\"]','uniprot'),(6,'8CME','3','[\"C\", \"F\", \"I\"]','[\"C\", \"F\", \"I\"]','uniprot'),(6,'8CTK','1','[\"A\", \"B\"]','[\"A\", \"B\"]','uniprot'),(6,'8W2E','1','[\"A\", \"B\"]','[\"A\", \"B\"]','uniprot'),(6,'9BF9','3','[\"C\"]','[\"G\"]','uniprot'),(6,'9CTU','3','[\"E\", \"F\"]','[\"A\", \"B\"]','uniprot'),(6,'9CTW','3','[\"E\", \"F\"]','[\"A\", \"B\"]','uniprot'),(6,'9EXA','1','[\"A\", \"B\"]','[\"A\", \"B\"]','uniprot');
/*!40000 ALTER TABLE `protein_structure` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-15 14:33:27

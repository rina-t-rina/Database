-- MySQL dump 10.13  Distrib 8.0.44, for macos15 (arm64)
--
-- Host: 127.0.0.1    Database: corona_nrdb
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'd3b460b6-cf99-11f0-9885-6c05d313e649:1-6748';

--
-- Table structure for table `gene`
--

DROP TABLE IF EXISTS `gene`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gene` (
  `gene_id` int NOT NULL AUTO_INCREMENT,
  `organism_id` int NOT NULL,
  `gene_symbol` varchar(64) NOT NULL,
  `gene_name` varchar(255) DEFAULT NULL,
  `start_pos` int NOT NULL,
  `end_pos` int NOT NULL,
  `strand` tinyint NOT NULL,
  `ncbi_geneid` bigint DEFAULT NULL,
  PRIMARY KEY (`gene_id`),
  UNIQUE KEY `uq_gene` (`organism_id`,`gene_symbol`,`start_pos`,`end_pos`,`strand`),
  CONSTRAINT `gene_ibfk_1` FOREIGN KEY (`organism_id`) REFERENCES `organism` (`organism_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gene`
--

LOCK TABLES `gene` WRITE;
/*!40000 ALTER TABLE `gene` DISABLE KEYS */;
INSERT INTO `gene` VALUES (1,1,'ORF1ab','ORF1ab polyprotein',266,21555,1,43740578),(2,1,'ORF1ab','ORF1a polyprotein',266,13483,1,43740578),(3,1,'S','surface glycoprotein',21563,25384,1,43740568),(4,1,'ORF3a','ORF3a protein',25393,26220,1,43740569),(5,1,'E','envelope protein',26245,26472,1,43740570),(6,1,'M','membrane glycoprotein',26523,27191,1,43740571),(7,1,'ORF6','ORF6 protein',27202,27387,1,43740572),(8,1,'ORF7a','ORF7a protein',27394,27759,1,43740573),(9,1,'ORF7b','ORF7b',27756,27887,1,43740574),(10,1,'ORF8','ORF8 protein',27894,28259,1,43740577),(11,2,'ORF1ab','ORF1ab polyprotein',265,21485,1,1489680),(12,2,'ORF1ab','ORF1a polyprotein',265,13413,1,1489680),(13,2,'S','spike glycoprotein',21492,25259,1,1489668),(14,2,'ORF3a','ORF3a protein',25268,26092,1,1489669),(15,2,'ORF3b','ORF3b protein',25689,26153,1,1489670),(16,2,'E','small envelope protein',26117,26347,1,1489671),(17,2,'M','membrane glycoprotein M',26398,27063,1,1489672),(18,2,'ORF6','ORF6 protein',27074,27265,1,1489673),(19,2,'ORF7a','ORF7a protein',27273,27641,1,1489674),(20,2,'ORF7b','ORF7b protein',27638,27772,1,1489675),(21,3,'orf1ab','1AB polyprotein',279,21514,1,14254602),(22,3,'orf1ab','1A polyprotein',279,13454,1,14254602),(23,3,'S','spike protein',21456,25517,1,14254594),(24,3,'orf3','NS3 protein',25532,25843,1,14254595),(25,3,'orf4a','NS4A protein',25852,26181,1,14254596),(26,3,'orf4b','NS4B protein',26093,26833,1,14254597),(27,3,'orf5','NS5 protein',26840,27514,1,14254598),(28,3,'E','envelope protein',27590,27838,1,14254599),(29,3,'M','membrane protein',27853,28512,1,14254600),(30,3,'N','nucleocapsid protein',28566,29807,1,14254601),(41,1,'N','nucleocapsid phosphoprotein',28274,29533,1,43740575),(42,1,'ORF10','ORF10 protein',29558,29674,1,43740576),(53,2,'ORF8a','ORF8a protein',27779,27898,1,1489676),(54,2,'ORF8b','ORF8b protein',27864,28118,1,1489677),(55,2,'N','nucleocapsid protein',28120,29388,1,1489678),(56,2,'unknown','ORF9b protein',28130,28426,1,1489679),(57,2,'N','ORF9a protein',28583,28795,1,1489678),(68,3,'orf8b','ORF8b protein',28762,29100,1,19910005);
/*!40000 ALTER TABLE `gene` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-15 14:33:27
